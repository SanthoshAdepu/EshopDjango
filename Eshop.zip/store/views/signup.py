from unicodedata import category
from django.shortcuts import render, redirect

from store.models.customer import Customer
from store.models.product import Product
from store.models.category import Category
from django.contrib.auth.hashers import make_password, check_password
from django.views import View


# Create your views here.

class Signup(View):
    def get(self, request):
        return render(request, 'orders/signup.html')

    def post(self, request):
        postdata = request.POST
        firstname = postdata.get('firstname')
        lastname = postdata.get('lastname')
        phone = postdata.get('phone')
        email = postdata.get('email')
        password = postdata.get('password')

        values = {
            'first_name': firstname,
            'last_name': lastname,
            'phone': phone,
            'email': email,
            'password': password
        }
        customer = Customer(first_name=firstname,
                            last_name=lastname,
                            phone=phone,
                            email=email,
                            password=password)
        error_message = self.validateCustomer(customer)
        # saving
        if not error_message:
            customer.password = make_password(password)
            customer.register()
            return redirect("homepage")
        else:
            data = {
                'error': error_message,
                'values': values
            }
            return render(request, 'orders/signup.html', data)

    def validateCustomer(self, customer):
        # validation
        error_message = None
        if not customer.first_name:
            error_message = "First Name is required!!"
        elif len(customer.first_name) < 4:
            error_message = "First Name must be more than 4 chars long"
        elif not customer.last_name:
            error_message = "Last Name is required!!"
        elif len(customer.last_name) < 4:
            error_message = "Last Name must be more than 4 chars long"
        elif not customer.phone:
            error_message = "Phone Number is required!!"
        elif len(customer.phone) < 10:
            error_message = "Phone Number must be of 10 chars long"
        elif not customer.password:
            error_message = "Password is required!!"
        elif len(customer.password) < 6:
            error_message = "Password must be more than 6 chars long"
        elif customer.isExist():
            error_message = "Email Address already exists"
        return error_message

