from cgi import print_exception
from unicodedata import category
from django.shortcuts import render, redirect

from store.models.customer import Customer
from store.models.product import Product
from store.models.category import Category
from store.models.order import Order
from django.contrib.auth.hashers import make_password, check_password
from django.views import View
from django.utils.decorators import method_decorator
from store.middlewares.auth import auth_middleware

# Create your views here.

class OrderView(View):
    def get(self, request):
        customer = request.session.get('customer')
        orders = Order.get_order_by_customer(customer)
        return render(request, "orders/order.html", {'orders': orders})
