from unicodedata import category
from django.shortcuts import render, redirect

from store.models.customer import Customer
from store.models.product import Product
from store.models.category import Category
from django.contrib.auth.hashers import make_password, check_password
from django.views import View


# Create your views here.

class Cart(View):
    def get(self, request):
        ids = list(request.session.get('cart').keys())
        products = Product.get_product_by_id(ids)
        return render(request, 'orders/cart.html', {'cart':products})